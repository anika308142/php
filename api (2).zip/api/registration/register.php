<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// get database connection
require_once('db.php');
//getting user values
if (isset($_POST['username'])&&isset($_POST['number'])&&isset($_POST['password'])) 
	# code...

//if(!empty($username)&&!empty($password)&&!empty($number) )
{  $username=$_POST['username'];
$number=$_POST['number'];
$password=$_POST['password'];
	
$SELECT = "SELECT number From userlist Where number=? Limit 1";
$Sql_Query = "insert into userlist(username,number,password) values ('$username','$number','$password')";
$stmt=$con->prepare($SELECT);
$stmt->bind_param("s",$number);
$stmt->execute();
$stmt->bind_result($number);
$stmt->store_result();
$rnum=$stmt->num_rows;
if($rnum==0){
//$stmt->close();
if(mysqli_query($con,$Sql_Query)){
   http_response_code(201);
  echo json_encode(array("message" => "Registration successful!"));
}
else{
        http_response_code(503);
  echo json_encode(array("message" => "Registration failed."));
    }
}
else {
	echo json_encode(array("message" => "Already registered"));
$stmt->close();
$con->close();
} 
 
}
else{
  
    // set response code - 400 bad request
  //  http_response_code(400);
  
    // tell the user
    echo json_encode(array("message" => "Unable to register. Data is incomplete."));
}

?>
