<?php
   session_start();
   unset($_SESSION["number"]);
    $_SESSION['logged_in'] = false;
       //  unset(   $_SESSION['time']     = time());
   //unset($_SESSION["password"]);
   echo json_encode(array("logged out"));

 //  echo 'You have cleaned session';
   //header('Refresh: 2; URL = login.php');
?>