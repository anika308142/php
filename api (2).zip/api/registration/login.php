<?php
      session_start();
error_reporting(0);
if ($_SERVER['REQUEST_METHOD'] == "GET") {
require_once('db.php');


if (isset($_GET['number']) && isset($_GET['password'])){
    
        // username and password sent from link
        $mynumber = $_GET['number'];
        $mypassword = $_GET['password'];
        $query      = "SELECT * FROM userlist WHERE number = '$mynumber' and password = '$mypassword'";
        $result     = mysqli_query($con, $query);
        $data       = mysqli_num_rows($result);
        if($data>0) {
         $_SESSION['logged_in'] = true;
            $_SESSION['time']     = time();
            $_SESSION['number'] = $mynumber;

      
            $error="log in successfull";
            echo json_encode(array("response"=>$error));
                        echo json_encode(array("number"=>$_SESSION['number']));

          //  header("Location:product/read.php");
           // header('location : ../product/create.php');
            }      
            else {
             $error = "log in failed";
            echo json_encode(array("response"=>$error));
        }
    }
}
#mysqli_close($connection);
?>