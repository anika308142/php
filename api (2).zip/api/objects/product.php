<?php
class Product{
  
    // database connection and table name
    private $conn;
    private $table_name = "products";
  
    // object properties
    public $id;
    public $name;
    
    public $category_id;
    public $category_name;
    public $created;
    public $image;

    public $number;
    public $division;
    public $district;
    public $upazila;
    public $category;
    public $sub_category;

    public $img1;
    public $img2;
    public $img3;
    public $img4;
    public $img5;

    public $status;
    public $brand_name;
    public $model;
    public $description;
    public $price;
    public $price_type;
    public $phone1;
    public $phone2;


    // constructor with $db as database connection
   
    public function __construct($db){
        $this->conn = $db;
    }
// read products
function read(){
  
    // select all query
    $query = "SELECT * FROM `products` ORDER BY `modified` DESC ";
  
    // prepare query statement
    $stmt = $this->conn->prepare($query);
  
    // execute query
    $stmt->execute();
  
    return $stmt;
}
// create product
function create(){
    $query = "INSERT INTO
                " . $this->table_name . "
            SET
                name=:name, price=:price, description=:description, category_id=:category_id, created=:created,image=:image";
  
    // prepare query
    $stmt = $this->conn->prepare($query);
  
    // sanitize
    $this->name=htmlspecialchars(strip_tags($this->name));
    $this->price=htmlspecialchars(strip_tags($this->price));
    $this->description=htmlspecialchars(strip_tags($this->description));
    $this->category_id=htmlspecialchars(strip_tags($this->category_id));
    $this->created=htmlspecialchars(strip_tags($this->created));
   
    // bind values
    $stmt->bindParam(":name", $this->name);
    $stmt->bindParam(":price", $this->price);
    $stmt->bindParam(":description", $this->description);
    $stmt->bindParam(":category_id", $this->category_id);
    $stmt->bindParam(":created", $this->created);
       $stmt->bindParam(":image", $this->image);

    // execute query
    if($stmt->execute()){
        return true;
    }
  
    return false;
      
}
function create_1_2_3(){
    $query = "INSERT INTO
                " . $this->table_name . "
            SET
               
               division=:division,
               district=:district,
               upazila=:upazila,
               category=:category,
               sub_category=:sub_category,

               img1=:img1,
               img2=:img2,
               img3=:img3,
               img4=:img4,
               img5=:img5,

               status=:status,
               brand_name=:brand_name,
               model=:model,
               description=:description,
               price=:price,
               price_type=:price_type,
               phone1=:phone1,
               phone2=:phone2";
  
    // prepare query
    $stmt = $this->conn->prepare($query);
  
    // sanitize
   // $this->number=htmlspecialchars(strip_tags($this->number));
    $this->division=htmlspecialchars(strip_tags($this->division));
    $this->district=htmlspecialchars(strip_tags($this->district));
    $this->upazila=htmlspecialchars(strip_tags($this->upazila));
    $this->category=htmlspecialchars(strip_tags($this->category));
    $this->sub_category=htmlspecialchars(strip_tags($this->sub_category));

    $this->img1=htmlspecialchars(strip_tags($this->img1));
    $this->img2=htmlspecialchars(strip_tags($this->img2));
    $this->img3=htmlspecialchars(strip_tags($this->img3));
    $this->img4=htmlspecialchars(strip_tags($this->img4));
   $this->img5=htmlspecialchars(strip_tags($this->img5));

    $this->price=htmlspecialchars(strip_tags($this->price));
    $this->description=htmlspecialchars(strip_tags($this->description));
    $this->status=htmlspecialchars(strip_tags($this->status));
    $this->brand_name=htmlspecialchars(strip_tags($this->brand_name));
   $this->model=htmlspecialchars(strip_tags($this->model));
    $this->price_type=htmlspecialchars(strip_tags($this->price_type));
    $this->phone1=htmlspecialchars(strip_tags($this->phone1));
    $this->phone2=htmlspecialchars(strip_tags($this->phone2));
   
    // bind values
    //$stmt->bindParam(":number",$this->number);
    $stmt->bindParam(":division", $this->division);
    $stmt->bindParam(":district", $this->district);
    $stmt->bindParam(":upazila", $this->upazila);
    $stmt->bindParam(":category", $this->category);
    $stmt->bindParam(":sub_category", $this->sub_category);

       $stmt->bindParam(":img1", $this->img1);
       $stmt->bindParam(":img2", $this->img2);
       $stmt->bindParam(":img3", $this->img3);
       $stmt->bindParam(":img4", $this->img4);
       $stmt->bindParam(":img5", $this->img5);

    $stmt->bindParam(":status", $this->status);
    $stmt->bindParam(":brand_name", $this->brand_name);
    $stmt->bindParam(":model", $this->model);
    $stmt->bindParam(":price", $this->price);
    $stmt->bindParam(":description", $this->description);
    $stmt->bindParam(":price_type", $this->price_type);
    $stmt->bindParam(":phone1", $this->phone1);
       $stmt->bindParam(":phone2", $this->phone2);

    // execute query
    if($stmt->execute()){
        return true;
    }
  
    return false;
      
}
/*function createAll(){
    $query = "INSERT INTO
                " . $this->table_name . "
            SET
                number=:number,
                division=:division, 
                district=:district;
                upazila=:upazila;
                category=:category;
                sub_category=:sub_category;
                img1=:img1;
                img2=:img3;
                img3=:img3;
                img4=:img4;
                img5=:img5;
                price=:price, 
                description=:description, 
                category_id=:category_id, 
                created=:created,
                image=:image"

                ;
  
    // prepare query
    $stmt = $this->conn->prepare($query);
  
    // sanitize
    $this->name=htmlspecialchars(strip_tags($this->name));
    $this->price=htmlspecialchars(strip_tags($this->price));
    $this->description=htmlspecialchars(strip_tags($this->description));
    $this->category_id=htmlspecialchars(strip_tags($this->category_id));
    $this->created=htmlspecialchars(strip_tags($this->created));
   
    // bind values
    $stmt->bindParam(":name", $this->name);
    $stmt->bindParam(":price", $this->price);
    $stmt->bindParam(":description", $this->description);
    $stmt->bindParam(":category_id", $this->category_id);
    $stmt->bindParam(":created", $this->created);
       $stmt->bindParam(":image", $this->image);

    // execute query
    if($stmt->execute()){
        return true;
    }
  
    return false;
      
}*/
// used when filling up the update product form
function readOne(){
  
    // query to read single record
    $query = "SELECT
                c.name as category_name, p.id, p.name, p.description, p.price, p.category_id, p.created,p.image
            FROM
                " . $this->table_name . " p
                LEFT JOIN
                    categories c
                        ON p.category_id = c.id
            WHERE
                p.id = ?
            LIMIT
                0,1";
  
    // prepare query statement
    $stmt = $this->conn->prepare( $query );
  
    // bind id of product to be updated
    $stmt->bindParam(1, $this->id);
  
    // execute query
    $stmt->execute();
  
    // get retrieved row
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
  
    // set values to object properties
    $this->name = $row['name'];
    $this->price = $row['price'];
    $this->description = $row['description'];
    $this->category_id = $row['category_id'];
    $this->category_name = $row['category_name'];
    $this->image = $row['image'];
}

// update the product
function update(){
  
    // update query
    $query = "UPDATE
                " . $this->table_name . "
            SET
                name = :name,
                price = :price,
                description = :description,
                category_id = :category_id,
                image = :image
            WHERE
                id = :id";
  
    // prepare query statement
    $stmt = $this->conn->prepare($query);
  
    // sanitize
    $this->name=htmlspecialchars(strip_tags($this->name));
    $this->price=htmlspecialchars(strip_tags($this->price));
    $this->description=htmlspecialchars(strip_tags($this->description));
    $this->category_id=htmlspecialchars(strip_tags($this->category_id));
    $this->id=htmlspecialchars(strip_tags($this->id));
     $this->image=htmlspecialchars(strip_tags($this->image));
  
  
    // bind new values
    $stmt->bindParam(':name', $this->name);
    $stmt->bindParam(':price', $this->price);
    $stmt->bindParam(':description', $this->description);
    $stmt->bindParam(':category_id', $this->category_id);
    $stmt->bindParam(':id', $this->id);
     $stmt->bindParam(':image', $this->image);
  
    // execute the query
    if($stmt->execute()){
        return true;
    }
  
    return false;
}
// delete the product
function delete(){
  
    // delete query
    $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
  
    // prepare query
    $stmt = $this->conn->prepare($query);
  
    // sanitize
    $this->id=htmlspecialchars(strip_tags($this->id));
  
    // bind id of record to delete
    $stmt->bindParam(1, $this->id);
  
    // execute query
    if($stmt->execute()){
        return true;
    }
  
    return false;
}
// search products
/*function search($keywords){
  
    // select all query
    $query = "SELECT
                c.name as category_name, p.id, p.name, p.description, p.price, p.category_id, p.created,p.image
            FROM
                " . $this->table_name . " p
                LEFT JOIN
                    categories c
                        ON p.category_id = c.id
            WHERE
                p.name LIKE ? OR p.description LIKE ? OR c.name LIKE ?
            ORDER BY
                p.created DESC";
  
    // preg_replace_callback_array(45rrrrrrrrrrrrrrrrrrrrrrrrrrrrrr, subject)re query statement
    $stmt = $this->conn->prepare($query);
  
    // sanitize
    $keywords=htmlspecialchars(strip_tags($keywords));
    $keywords = "%{$keywords}%";
  
    // bind
    $stmt->bindParam(1, $keywords);
    $stmt->bindParam(2, $keywords);
    $stmt->bindParam(3, $keywords);
  
    // execute query
    $stmt->execute();
  
    return $stmt;
}*/
// read products with pagination

function search_by_category($keywords){
  
    // select all query
    $query = "SELECT * FROM `products` 
            WHERE
               category LIKE ?
            ORDER BY `modified` DESC ";
  
    // preg_replace_callback_array(45rrrrrrrrrrrrrrrrrrrrrrrrrrrrrr, subject)re query statement
    $stmt = $this->conn->prepare($query);
  
    // sanitize
    $keywords=htmlspecialchars(strip_tags($keywords));
    $keywords = "%{$keywords}%";
  
    // bind
    $stmt->bindParam(1, $keywords);
  //  $stmt->bindParam(2, $keywords);
   // $stmt->bindParam(3, $keywords);
  
    // execute query
    $stmt->execute();
  echo json_encode(  array("msg" => $stmt ));
    return $stmt;
}
function search_by_category_location($keywords,$keywords2){
 
    // select all query
    $query = " SELECT * FROM `products`  
    WHERE (category LIKE ? OR sub_category LIKE ? )AND (division LIKE ? OR district LIKE ?) 
    ORDER BY `modified` DESC";
  
    // preg_replace_callback_array(45rrrrrrrrrrrrrrrrrrrrrrrrrrrrrr, subject)re query statement
    $stmt = $this->conn->prepare($query);
  
    // sanitize
    $keywords=htmlspecialchars(strip_tags($keywords));
    $keywords = "%{$keywords}%";
    $keywords2=htmlspecialchars(strip_tags($keywords2));
   $keywords2 = "%{$keywords2}%";
  /* echo json_encode(
        //array("message" => "No products found.")
        array("message" => $keywords)

    );
   echo json_encode(
        //array("message" => "No products found.")
        array("message" => $keywords2)

    );*/
    // bind
  $stmt->bindValue(1, $keywords);
    $stmt->bindValue(2, $keywords);
    $stmt->bindValue(3, $keywords2);
   $stmt->bindValue(4, $keywords2);
//  $stmt->bind_param("ssss",$keywords,$keywords,$keywords2,$keywords2);
 // echo json_encode(c);
   // echo json_encode(d);
    // execute query
    $stmt->execute();
    // echo json_encode(array("return"=>$stmt));

    return $stmt;
}
// read products with pagination

public function readPaging($from_record_num, $records_per_page){
  
    // select query
    $query = "SELECT
                c.name as category_name, p.id, p.name, p.description, p.price, p.category_id, p.created,p.image
            FROM
                " . $this->table_name . " p
                LEFT JOIN
                    categories c
                        ON p.category_id = c.id
            ORDER BY p.created DESC
            LIMIT ?, ?";
  
    // prepare query statement
    $stmt = $this->conn->prepare( $query );
  
    // bind variable values
    $stmt->bindParam(1, $from_record_num, PDO::PARAM_INT);
    $stmt->bindParam(2, $records_per_page, PDO::PARAM_INT);
  
    // execute query
    $stmt->execute();
  
    // return values from database
    return $stmt;
}
// used for paging products
public function count(){
    $query = "SELECT COUNT(*) as total_rows FROM " . $this->table_name . "";
  
    $stmt = $this->conn->prepare( $query );
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
  
    return $row['total_rows'];
}
}
?>