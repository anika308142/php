<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
  session_start();
// get database connection
include_once '../config/database.php';
  
// instantiate product object
include_once '../objects/product.php';
  
$database = new Database();
$db = $database->getConnection();
  
$product = new Product($db);
  

// make sure data is not empty
if(1)
{
// $POSTget posted data
$number=$_SESSION['number'];//1
$division=$_POST['division'];
$district=$_POST['district'];
$upazila=$_POST['upazila'];
$category=$_POST['category'];//5
$sub_category=$_POST['sub_category'];
$status=$_POST['status'];
$brand_name=$_POST['brand_name'];
$model=$_POST['model'];
$registration_year=$_POST['registration_year'];//10
$engine_capacity=$_POST['engine_capacity'];
$fuel_type=$_POST['fuel_type'];
$body_type=$_POST['body_type'];
$description=$_POST['description'];
$price=$_POST['price'];//15
$price_type=$_POST['price_type'];
$property_type=$_POST['property_type'];
$service_name=$_POST['service_name'];
$product_name=$_POST['product_name'];
$phone1=$_POST['phone1'];//20
$phone2=$_POST['phone2'];
$img1 = $_FILES['img1']['name'];
$img2 = $_FILES['img2']['name'];
$img3 = $_FILES['img3']['name'];
$img4 = $_FILES['img4']['name'];//25
$img5 = $_FILES['img5']['name'];
$number=$_SESSION['number']; 

  $product->number = $number;//1
  $product->division = $division;
  $product->district = $district;
  $product->upazila=$upazila;
  $product->category = $category;
  $product->sub_category = $sub_category;//5
 // $product->img1=$img1;
 // $product->img2=$img2;
 // $product->img3=$img3;
 // $product->img4=$img4;
 // $product->img5=$img5;//10
  $product->status=$status;
  $product->brand_name=$brand_name;
  $product->model=$model;
  $product->registration_year=$registration_year;
  $product->engine_capacity=$engine_capacity;//15
  $product->fuel_type=$fuel_type;
  $product->gear=$gear;
  $product->body_type=$body_type;
  $product->description=$description;
  $product->price=$price;//20
  $product->price_type=$price_type;
  $product->property_type=$property_type;
  $product->service_name=$service_name;
  $product->product_name=$product_name;
  //25
  $product->phone1=$phone1;
  $product->phone2=$phone2;

    
   // $fileType = explode($image['type'], '/')[1];
    $imageName1 = rand(100000, 9999999)  .basename($img1);
    $imageName2 = rand(100000, 9999999)  .basename($img2);
    $imageName3 = rand(100000, 9999999)  .basename($img3);
    $imageName4 = rand(100000, 9999999)  .basename($img4);
    $imageName5 = rand(100000, 9999999)  .basename($img5);
    //$imagePath = basename(__DIR__) . '/images/'. $imageName;
    $uploadPath1 =  "images/". $imageName1;
    $uploadPath2 =  "images/". $imageName2;
    $uploadPath3 =  "images/". $imageName3;
    $uploadPath4 =  "images/". $imageName4;
    $uploadPath5 =  "images/". $imageName5;



   // move_uploaded_file($_FILES['image']['name'], $imagePath);
              $product->img1 = 'http://localhost/api/product/images/' . $imageName1; 
               $product->img2 = 'http://localhost/api/product/images/' . $imageName2; 
                $product->img3 = 'http://localhost/api/product/images/' . $imageName3; 
                 $product->img4 = 'http://localhost/api/product/images/' . $imageName4; 
                  $product->img5 = 'http://localhost/api/product/images/' . $imageName5; 
    
       // $actualpath = "http://localhost/api/$path";
       
       if($product->createAll()&&
        (move_uploaded_file)($_FILES['img1']['tmp_name'], $uploadPath1)&&
(move_uploaded_file)($_FILES['img2']['tmp_name'], $uploadPath2)&&
(move_uploaded_file)($_FILES['img3']['tmp_name'], $uploadPath3)&&
(move_uploaded_file)($_FILES['img4']['tmp_name'], $uploadPath4)&&
(move_uploaded_file)($_FILES['img5']['tmp_name'], $uploadPath5)
     ){


        http_response_code(201);
  
        // tell the user
        echo json_encode(array("message" => "Product was created."));
    }
  
    // if unable to create the product, tell the user
    else{
  
        // set response code - 503 service unavailable
        http_response_code(503);
  
        // tell the user
        echo json_encode(array("message" => "Unable to create product."));
    }

  }
// tell the user data is incomplete
/*else{
  
    // set response code - 400 bad request
    http_response_code(400);
  
    // tell the user
    echo json_encode(array("message" => "Unable to create product. Data is incomplete."));
}
*/

?>