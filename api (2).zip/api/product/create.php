<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
  session_start();
// get database connection
include_once '../config/database.php';
  
// instantiate product object
include_once '../objects/product.php';
  
$database = new Database();
$db = $database->getConnection();
  
$product = new Product($db);
  

// make sure data is not empty
if(1
    //!empty($data['name']) &&
  //  !empty($data['price']) &&
   // !empty($data['description']) &&
   // !empty($data['category_id'])
){
// $POSTget posted data
$name=$_POST['name'];
$price=$_POST['price'];
$description=$_POST['description'];
$category_id=$_POST['category_id'];
 $number=$_SESSION['number']; 
   $created=$_POST['created'];
//$image = $_POST['image'];
$image = $_FILES['image']['name'];
//$number='number';
//$number=$_SESSION['number'];
//$number=$_POST['number'];
/*$product->name = NULL;
  $product->number = NULL;
    $product->price = NULL;
    $product->description = NULL;
    $product->category_id = NULL;
    $product->created = NULL;
    $product->number=NULL;
 $product->image = NULL; */

  $product->name = $name;
  $product->number = $number;
    $product->price = $price;
    $product->description = $description;
    $product->category_id = $category_id;
    $product->created = date('Y-m-d H:i:s');
   $product->number=$number;

    // set product property values
    /*
    $product->name = $data['name'];
    $product->price = $data['price'];
    $product->description = $data['description'];
    $product->category_id = $data['category_id'];
    $product->created = date('Y-m-d H:i:s');

    */
    //$product->image=$_FILES['image']['name'];
    //$image1 = $data['image'];

   // $fileType = explode($image['type'], '/')[1];
    $imageName = rand(100000, 9999999)  .basename($image);
    $imagePath = basename(__DIR__) . '/images/'. $imageName;
    $uploadPath =  "images/". $imageName;

   // move_uploaded_file($_FILES['image']['name'], $imagePath);
              $product->image = 'http://localhost/api/product/images/' . $imageName; 
    //  $product->image = $imagePath; 
  /*  $sql ="SELECT id FROM products ORDER BY id ASC";
        
        $res = mysqli_query($con,$sql);
        
  $id = 0;
        
        while($row = mysqli_fetch_array($res)){
                $id = $row['id'];
        }

$path = "images/$id.png";
        
        $actualpath = "http://localhost/api/$path";
        
       // $sql = "INSERT INTO product (image) VALUES ('$actualpath')";*/
// file_put_contents($imagepath,base64_decode($image));
        // set response code - 201 created
       if($product->create()&&(move_uploaded_file)($_FILES['image']['tmp_name'], $uploadPath)){

    // create the product
 // if($product->create()&&file_put_contents($uploadPath,$image)){
    //if($product->create()&&file_put_contents($uploadPath,$image)){
        http_response_code(201);
  
        // tell the user
        echo json_encode(array("message" => "Product was created."));
    }
  
    // if unable to create the product, tell the user
    else{
  
        // set response code - 503 service unavailable
        http_response_code(503);
  
        // tell the user
        echo json_encode(array("message" => "Unable to create product."));
    }

  }
// tell the user data is incomplete
/*else{
  
    // set response code - 400 bad request
    http_response_code(400);
  
    // tell the user
    echo json_encode(array("message" => "Unable to create product. Data is incomplete."));
}
*/

?>